angular.module('mainApp', ['coreModule', 'ngRoute', 'BlogModule'])

.config(['$routeProvider', '$locationProvider',
  function ($routeProvider, $locationProvider) {
    $routeProvider
        .when('/home', {
            templateUrl: 'content/home.html',
            controller: 'ContentCtrl'
        })

        .when('/blog', {
            templateUrl: '../blog/blog.html',
            controller: 'ContentCtrl'
        })
        .when('/b/:id', {
            templateUrl: '../blog/blog.html',
            controller: 'ContentCtrl'
        })

        .when('/azure', {
            templateUrl: 'content/azure.html',
            controller: 'ContentCtrl'
        })
        .when('/skype', {
            templateUrl: 'content/skype.html',
            controller: 'ContentCtrl'
        })
        .when('/sharepoint', {
            templateUrl: 'content/sharepoint.html',
            controller: 'ContentCtrl'
        })
        .when('/server', {
            templateUrl: 'content/server.html',
            controller: 'ContentCtrl'
        })

        .when('/o365', {
            templateUrl: 'content/o365.html',
            controller: 'ContentCtrl'
        })

        .when('/exchange', {
            templateUrl: 'content/exchange.html',
            controller: 'ContentCtrl'
        })
        .when('/systemcenter', {
            templateUrl: 'content/systemcenter.html',
            controller: 'ContentCtrl'
        })

        .when('/whoweare', {
            templateUrl: 'content/whoweare.html',
            controller: 'ContentCtrl'
        })
        .when('/whatwedo', {
            templateUrl: 'content/whatwedo.html',
            controller: 'ContentCtrl'
        })
        .when('/contact', {
            templateUrl: 'contact/contactTemplate.html',
            controller: 'ContentCtrl'
        })
        .otherwise({
            redirectTo: '/',
            templateUrl: 'content/home.html'
            
        });
    $locationProvider
        .html5Mode(false)
        .hashPrefix('!');
  }])

.run([function () {
    console.log("mainApp running...");
}])

.controller('ContentCtrl', ['$route', '$routeParams', '$location', '$scope', function ($route, $routeParams, $location, $scope) {
        this.$route = $route;
        this.$location = $location;
        this.$routeParams = $routeParams;
        $scope.activePage = this.$location.url().toString();
        //console.log($scope.activePage);

        if ($scope.activePage == '/') {
            $scope.activePage = '/home'
        }

        //
        $scope.setActivePage = function (val) {
            $scope.activePage = val;
        }

        //
        $scope.getServiceActive = function () {
            var serviceActive = false;
            if ($scope.activePage.includes('/azure')) {
                serviceActive = true;
            }
            else if ($scope.activePage == '/o365') {
                serviceActive = true;
            }
            else if ($scope.activePage == '/exchange') {
                serviceActive = true;
            }
            else if ($scope.activePage == '/skype') {
                serviceActive = true;
            }
            else if ($scope.activePage == '/systemcenter') {
                serviceActive = true;
            }
            else if ($scope.activePage == '/server') {
                serviceActive = true;
            }
            else if ($scope.activePage == '/sharepoint') {
                serviceActive = true;
            }
            return serviceActive;
        }
       
}])
//     
// End Module mainApp
//


/* ************************************************************************************************
 *  Directives framing the main page
 */
angular.module("coreModule",[])

	.directive("coreNavbar", function () {
	    return {
	        scope: {},
			restrict: "E",
			replace: true,
			transclude:true,
			templateUrl: "../core/navigation.html"
		}
	})

	.directive("coreHeader", function () {
	    return {
	        scope: {},
	        restrict: "E",
	        replace: true,
	        transclude: true,
	        templateUrl: "../core/jumbotron.html"
	    }
	})

    .directive("coreFooter", function () {
        return {
            scope: {},
            restrict: "E",
            replace: true,
            transclude: true,
            templateUrl: "../core/footer.html"
        }
    })

; // End Module 

//(function () {
angular.module('navModule', [])
.config([function () {
    console.log("navModule Config ran");
}])
.run([function () {
    console.log("navModule running...");
}])
.controller('NavCtrl', ['$scope', function ($scope) {
    $scope.nav = [
		{
		    name: "Home",
		    href: "index.html"
		},
		{
		    name: "Blog",
		    href: "blog.html"
		},
		{
		    name: "Azure Professional Services",
		    href: "azure.html"
		},
		{
		    name: "Office 365 Professional Services",
		    href: "o365.html"
		},
		{
		    name: "Analytics",
		    href: "analytics.html"
		},
		{
		    name: "Managed Services",
		    href: "managedservices.html"
		},
		{
		    name: "About Us",
		    href: "about.html"
		},
		{
		    name: "Contact Us",
		    href: "contact.html"
		}
    ]

    $scope.index = 0;
    $scope.setIndex = function (val) {
        $scope.index = val;
        console.log(val);
    }
    $scope.getIndex = function () {
        console.log($scope.index);
        return ($scope.index);
    }

}])
//})




; // End All