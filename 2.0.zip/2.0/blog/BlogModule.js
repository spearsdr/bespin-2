﻿/* ************************************************************************************************
 * Self contained BLOG rendering engine.
 */
angular.module("BlogModule", [])
.directive('blogPage', [function () {
    return {
        scope: {},
        restrict: "E",
        replace: true,
        transclude: true,
        templateUrl: "blog/blogTemplate.html",
        controller: ['$scope', '$http', '$routeParams', '$location', function ($scope, $http, $routeParams, $location) {
            $scope.posts = {};
            $http.get('blog/posts.json')
            .success(function (data) {
                $scope.posts = data;
                console.log("got posts...");
                //console.log($routeParams.id)
            })
            $scope.paraLimit = "2";
            $scope.postUrl = $location.absUrl();

            $scope.showPost = function (routeValue) {
                console.log(routeValue);
                if (!$routeParams.id || $routeParams.id == routeValue) {
                    if ($routeParams.id == routeValue) {
                        $scope.paraLimit = "all";
                        $scope.apiQueryTerm = routeValue.replace(".", "(dot)");
                        $scope.commentAPIurl = "https://microsoft-apiapp750e5382c7f04eed8dd334fb95f3c103.azurewebsites.net/api/tweet/" + $scope.apiQueryTerm;
                        console.log($scope.apiQueryTerm);
                    }
                    return true;
                }
                else {
                    return false;
                }
            }
        }]
    }
}])


;// End Blog