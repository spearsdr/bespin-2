﻿/* ************************************************************************************************
 * Self contained Contact form
 */
angular.module("ContactFormModule", [])
.directive('contactForm', [function () {
    return {
        scope: {},
        restrict: "E",
        replace: true,
        transclude: true,
        templateUrl: "contact/contactTemplate.html",
        controller: ['$scope', '$http', function ($scope, $http) {
            $scope.formData = {};
            $scope.showSuccess = false,
            $scope.showProcessing = false,
            $scope.showError = false,
            $scope.processForm = function () {
                // clear setting from previous processForm() execution.
                $scope.showProcessing = true;
                $scope.showSuccess = false,
                $scope.showError = false,
                console.log("in processForm()...");
                // URL of API to receive POST
                var myurl = 'https://httplistener0736485390254063b29d790c45340c38.azurewebsites.net/contact';
                var myReq = $http({
                    method: "POST",         // set method
                    url: myurl,             // apply URL obj
                    data: $scope.formData,  // apply data obj
                })
                .then(                      //  asysnc: When successfully complete do this
                    /* Success function */
                    function (response) {
                        $scope.showProcessing = false;
                        $scope.showSuccess = true;
                    },
                    /* Error Function */
                    function (result) {
                        $scope.showError = true;
                    }
                )
                $scope.formData = "";       // Clear data from the form/view

            }
        }
        ]
    } // End Controller
}])
; //  End contactForm